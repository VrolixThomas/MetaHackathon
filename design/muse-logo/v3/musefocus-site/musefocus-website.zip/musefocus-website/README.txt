MuseFocus website

Open index.html manually with its adjacent files. No server or installation is needed.

This is an unpublished static introduction with an interactive product illustration. All examples are local; no account or microphone is accessed.

Bundled font license: assets/FONT-LICENSE.txt
